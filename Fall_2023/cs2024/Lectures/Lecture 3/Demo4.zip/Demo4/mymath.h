//
// CS2024 -- Lecture #3
//
// Demo #4 -- Using <cmath>
//


// We only need a declaration for squareIt() in this file
long squareIt(long);
