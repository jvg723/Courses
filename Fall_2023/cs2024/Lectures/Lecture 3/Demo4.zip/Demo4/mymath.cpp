//
// CS2024 -- Lecture #3
//
// Demo #4 -- Using <cmath>
//

#include <cmath>

long squareIt(long x)
{
	return pow(x,2);	
}
