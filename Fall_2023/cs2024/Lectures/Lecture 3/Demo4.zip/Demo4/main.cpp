//
// CS2024 -- Lecture #3
//
// Demo #4 -- using <cmath>

#include <iostream>
#include "mymath.h"

int main (int argc, char *argv[]) {
    std::cout << "5 squared is " << squareIt(5) << std::endl;
    return 0;
}
